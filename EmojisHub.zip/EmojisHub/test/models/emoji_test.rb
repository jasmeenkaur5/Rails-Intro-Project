require "test_helper"

class EmojiTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
