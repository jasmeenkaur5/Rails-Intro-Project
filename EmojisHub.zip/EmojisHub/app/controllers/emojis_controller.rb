class EmojisController < ApplicationController
  def index
    @emojis = Emoji.all.order(:name).page(params[:page]).per(25)

    if params[:query].present?
      @emojis = @emojis.where("name LIKE ?", "%#{params[:query]}%")
    end

    if params[:category_id].present?
      @emojis = @emojis.joins(:group).where(groups: { category_id: params[:category_id] })
    end
  end

  def show
    @emoji = Emoji.find(params[:id])
    @group = @emoji.group
    @category = @group.category
  end
end
