class Emoji < ApplicationRecord
  belongs_to :group

  validates :name, presence: true
  validates :htmlCode, presence: true
  validates :unicode, presence: true
  validates :group_id, presence: true
end
