class Group < ApplicationRecord
  belongs_to :category
  has_many :emojis, dependent: :destroy

  validates :name, presence: true
  validates :category_id, presence: true
end
