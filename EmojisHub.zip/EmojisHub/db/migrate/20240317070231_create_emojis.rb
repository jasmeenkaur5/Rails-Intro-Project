class CreateEmojis < ActiveRecord::Migration[7.1]
  def change
    create_table :emojis do |t|
      t.string :name
      t.text :htmlCode
      t.text :unicode
      t.references :group, null: false, foreign_key: true

      t.timestamps
    end
  end
end
