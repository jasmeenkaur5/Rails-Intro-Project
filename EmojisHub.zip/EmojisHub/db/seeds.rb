require 'open-uri'
require 'json'
require 'faker'

# Function to fetch data from the API
def fetch_emojis_from_api(api_url)
  JSON.parse(URI.open(api_url).read)
end

# Use the function to get emoji data
emoji_data = fetch_emojis_from_api('https://emojihub.yurace.pro/api/all')

# Process each emoji and store it in the database
emoji_data.each do |emoji_hash|
  category_name = emoji_hash['category']
  group_name = emoji_hash['group']

  # Find or create the category
  category = Category.find_or_create_by!(name: category_name)

  # Find or create the group within the category
  group = category.groups.find_or_create_by!(name: group_name)

  # Create the emoji within the group and add example text using Faker
  group.emojis.create!(
    name: emoji_hash['name'],
    htmlCode: emoji_hash['htmlCode'].join, 
    unicode: emoji_hash['unicode'].join,
    exampleText: Faker::Lorem.sentence(word_count: 3, supplemental: true, random_words_to_add: 2).chomp('.') + " #{emoji_hash['name']}."
  )
end

puts 'Emoji data with example texts has been seeded successfully!'
